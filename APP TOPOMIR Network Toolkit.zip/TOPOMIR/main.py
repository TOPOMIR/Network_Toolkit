import webview
import os
import sys

def get_path():
    if getattr(sys, 'frozen', False):
        return os.path.join(sys._MEIPASS, 'index.html')
    return os.path.abspath('index.html')

window = webview.create_window('TOPOMIR PRO', get_path(), width=1200, height=800)
webview.start()